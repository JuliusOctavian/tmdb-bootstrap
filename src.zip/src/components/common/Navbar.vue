<template>
  $END$
</template>

<script>
  export default {
    name: "Navbar"
  }
</script>

<style scoped>

</style>