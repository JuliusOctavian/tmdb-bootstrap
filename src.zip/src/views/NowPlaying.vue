<template>
  $END$
</template>

<script>
  export default {
    name: "NowPlaying"
  }
</script>

<style scoped>

</style>